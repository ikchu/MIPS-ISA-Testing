extern uint32_t ConvertWordToBigEndian(uint32_t value);
extern uint16_t ConvertHalfWordToBigEndian(uint16_t value);
